package TestJade;

import java.util.Scanner;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;

public class InitJoueur {

	public static void main(String[] args) {
		int choix=999;
		Scanner sc= new Scanner(System.in);
		System.out.println("Bienvenue! Saisissez votre nom: c'est important...");
		String nameJoueur= sc.nextLine();
		String nameRoom;
		int tmp;
		while ((0<choix && choix<4) || choix==999) {
			System.out.println(nameJoueur+", que souhaitez vous faire?\n 1-Cr�er un salon\n 2-Rejoindre un salon\n 3-R�gles du jeu\n Autre-Quitter");
			choix= sc.nextInt();
			switch (choix) {
				case (1):
					System.out.println("Quel est le nom de la nouvelle salle ?");
					nameRoom=sc.nextLine();
					System.out.println("Cr�ation de la salle...Veuillez patienter");
					createRoom(nameRoom);
					break;
				case (2):
					System.out.println("Saisir le num�ro de la salle � rejoindre: ");
					break;
				case (3):
					System.out.println("Les r�gles du jeu seront affich�s dans la version finale du jeu!");
					break;
				default:
					System.out.println("Au revoir, "+nameJoueur);
				}
			}
		

	}
	
	public static void createRoom(String nameSalle) {
		try {
			Runtime rt= Runtime.instance();
			Properties ppt= new ExtendedProperties();
			ppt.setProperty(Profile.CONTAINER_NAME, nameSalle);
			ProfileImpl pf=new ProfileImpl(ppt);
			pf.setParameter(ProfileImpl.MAIN_HOST, "localhost");//mettre l'adresse ip si autre machine
			AgentContainer ac= rt.createAgentContainer(pf);
			ac.start();
			System.out.println();
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
