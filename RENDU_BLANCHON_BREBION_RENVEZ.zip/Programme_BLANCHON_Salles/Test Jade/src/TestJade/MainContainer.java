package TestJade;

import java.util.Scanner;

import agents.Joueur;
import jade.core.AID;
import jade.core.ContainerID;
import jade.core.Location;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;
import jade.wrapper.StaleProxyException;

public class MainContainer {

	public static void main(String[] args) {
		
		try {
			Scanner sc= new Scanner(System.in);
            Runtime rt = Runtime.instance();
            Properties p = new ExtendedProperties();
            p.setProperty(Profile.GUI,"true");
            ProfileImpl pc = new ProfileImpl(p);
            AgentContainer container = rt.createMainContainer(pc);
            String nameJoueur= Joueur.setName(sc);
            AgentController act= container.createNewAgent(nameJoueur, "agents.Joueur", new Object[] {container.getContainerName()});
            container.start();
            act.start();
            System.out.println("PANDEMUS\n Made by 1xU\n");
    		System.out.println("Veuillez lancer un salon pour jouer.");
        } catch (ControllerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}
	
	public static void newJoueur(AgentContainer container) {
		try {
			Scanner sc= new Scanner(System.in);
			String nameJoueur= Joueur.setName(sc);
			AgentController act= container.createNewAgent(nameJoueur, "TestJade.Joueur", new Object[] {});
			act.start();
		} catch (StaleProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
