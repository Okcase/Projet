package agents;

import java.util.Scanner;

import jade.core.Location;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;

public class Guest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String nameJoueur= Joueur.setName(sc);
		Runtime rt= Runtime.instance();
		Properties pp= new ExtendedProperties();
		//ProfileImpl pf=new ProfileImpl(false);
		pp.setProperty(ProfileImpl.DETECT_MAIN,"true");
		//pf.setParameter(ProfileImpl.MAIN_HOST, "localhost");
		//var guest= new StringBuilder();
		//guest.append(nameJoueur + ":agents.Joueur");
		//pp.setProperty(Profile.AGENTS, guest.toString());
		Location l= pp.getProperty(ProfileImpl.DETECT_MAIN); 
		AgentController act= .createNewAgent(nameJoueur,"agents.Joueur", new Object[] {});
	}

}
