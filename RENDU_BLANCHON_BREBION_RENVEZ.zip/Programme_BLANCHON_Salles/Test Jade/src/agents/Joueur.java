package agents;

import java.util.Scanner;

import jade.core.AID;
import jade.core.Agent;
import jade.core.Location;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import TestJade.InitJoueur;

public class Joueur extends Agent {
	protected void setup() {
		Scanner sc= new Scanner(System.in);
		Location l= this.here();
		System.out.println(this.getLocalName()+": Je suis sur Pandemus!");
		addBehaviour(new behaviours.Menu()); 
	
	}
	protected void takeDown() {
		System.out.println(this.getName()+" est parti...");
	}
	
	public static String setName(Scanner sc) {
		System.out.println("Bienvenue! Saisissez votre nom: c'est important...");
		return sc.nextLine();
	}
	
	public String name() {
		return this.getLocalName();
	}
	
}
