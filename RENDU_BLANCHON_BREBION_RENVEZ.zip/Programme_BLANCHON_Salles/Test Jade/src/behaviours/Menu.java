package behaviours;

import java.util.Scanner;

import TestJade.InitJoueur;
import jade.core.behaviours.CyclicBehaviour;

public class Menu extends CyclicBehaviour{
	int choix;
	String nameRoom;
	Scanner sc= new Scanner(System.in);
	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.println(myAgent.getLocalName()+", que souhaitez vous faire?\n 1-Cr�er un salon\n 2-Rejoindre un salon\n 3-R�gles du jeu\n Autre-Quitter");
		choix= sc.nextInt();
		
		switch (choix) {
			case (1):
				System.out.println("Quel est le nom de la nouvelle salle ?");
				sc.nextLine();
				nameRoom=sc.nextLine();
				System.out.println("Cr�ation de la salle...Veuillez patienter");
				InitJoueur.createRoom(nameRoom);
				
				break;
			case (2):
				System.out.println("Saisir le nom de la salle � rejoindre: ");
				System.out.println(myAgent.here().getName());
				break;
			case (3):
				System.out.println("Les r�gles du jeu seront affich�s dans la version finale du jeu!");
				break;
			default:
				System.out.println("Au revoir, "+myAgent.getLocalName());
				block();
			}
	
	}
}
