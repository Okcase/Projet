package TestJade;
import java.util.Scanner;
import jade.core.AID;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;

public class JadeContainer {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Bienvenue! Saisissez votre nom: c'est important...");
		String nameJoueur= sc.nextLine();
		try {
			Runtime rt= Runtime.instance();
			ProfileImpl pf=new ProfileImpl(false);
			pf.setParameter(ProfileImpl.MAIN_HOST, "localhost");//mettre l'adresse ip si autre machine
			AgentContainer ac= rt.createAgentContainer(pf);
			AgentController act= ac.createNewAgent(nameJoueur, "TestJade.Joueur", new Object[] {});
			act.start();
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
