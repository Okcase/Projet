package agents;

import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;

public class Guest {

	public static void main(String[] args) {
		Runtime rt= Runtime.instance();
		Properties pp= new ExtendedProperties();
		ProfileImpl pf=new ProfileImpl(false);
		pp.setProperty(pf.DETECT_MAIN,"true");
		pf.setParameter(ProfileImpl.MAIN_HOST, "localhost");
		

	}

}
