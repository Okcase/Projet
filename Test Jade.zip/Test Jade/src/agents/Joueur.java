package agents;

import java.util.Scanner;

import jade.core.AID;
import jade.core.Agent;
import jade.core.Location;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import TestJade.InitJoueur;

public class Joueur extends Agent {
	protected void setup() {
		Scanner sc= new Scanner(System.in);
		Location l= this.here();
		System.out.println(this.getLocalName()+": Je suis sur Pandemus!");
		addBehaviour(new CyclicBehaviour(this) {
			int choix;
			String nameRoom;
			@Override
			public void action() {
				// TODO Auto-generated method stub
				System.out.println(name()+", que souhaitez vous faire?\n 1-Cr�er un salon\n 2-Rejoindre un salon\n 3-R�gles du jeu\n Autre-Quitter");
				choix= sc.nextInt();
				
				switch (choix) {
					case (1):
						System.out.println("Quel est le nom de la nouvelle salle ?");
						sc.nextLine();
						nameRoom=sc.nextLine();
						System.out.println("Cr�ation de la salle...Veuillez patienter");
						InitJoueur.createRoom(nameRoom);
						break;
					case (2):
						System.out.println("Saisir le num�ro de la salle � rejoindre: ");
						break;
					case (3):
						System.out.println("Les r�gles du jeu seront affich�s dans la version finale du jeu!");
						break;
					default:
						System.out.println("Au revoir, "+name());
						block();
					}
			
			}
				
			});
		//addBehaviour();
		}
	
	
	protected void takeDown() {
		System.out.println(this.getName()+" est parti...");
	}
	
	public static String setName(Scanner sc) {
		System.out.println("Bienvenue! Saisissez votre nom: c'est important...");
		return sc.nextLine();
	}
	
	public String name() {
		return this.getLocalName();
	}
	
}
