package behaviours;

public class Menu {

}
